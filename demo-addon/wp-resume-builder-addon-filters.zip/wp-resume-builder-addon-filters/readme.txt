=== WP Resume Builder Addon Filters  ===
	Contributors: paratheme
	Donate link: http://paratheme.com
	Tags: WP Resume Builder
	Requires at least: 3.8
	Tested up to: 4.2.2
	Stable tag: 1.0.0
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html

	Demo Addon for "WP Resume Builder" used for Themes

== Description ==



== Changelog ==


	= 1.0 =
	
    * 12/07/2015 Initial release.
