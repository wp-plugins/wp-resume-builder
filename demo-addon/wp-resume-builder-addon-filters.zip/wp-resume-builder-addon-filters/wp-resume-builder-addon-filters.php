<?php
/*
Plugin Name: WP Resume Builder Addon Filters
Plugin URI: http://paratheme.com/
Description: Demo Addon for "WP Resume Builder" used for Themes
Version: 1.0.0
Author: paratheme
Author URI: http://paratheme.com
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Copyright: 	2015 ParaTheme

*/

if ( ! defined('ABSPATH')) exit;  // if direct access 


class wp_resume_builderAddonFilters{
	
	public function __construct(){

		add_filter('wp_rb_filter_sections', array( $this, 'wp_rb_sections_add' ));
		add_filter('wp_rb_filter_sections_args', array( $this, 'wp_rb_sections_args_add' ));

		add_filter('wp_rb_section_properties', array( $this, 'wp_rb_section_properties_add' ));
					
					
		}

	// example for team_member_social_field
	public function wp_rb_sections_add($sections)
		{
			$sections_new = array_merge($sections, array("tour"=>"Tour"));
			//unset($sections_new['social']); // remove sections ex: social
			return $sections_new;
		}
		

		
		
	public function wp_rb_sections_args_add($entries_args)
		{
			return array_merge($entries_args, array('tour'=> array('name','location','details')));
		}
		
		
		
	public function wp_rb_section_properties_add($properties)
		{
			return array_merge($properties, array("short-desc"=>"Short Description"));
		}		
		


	}
	
	new wp_resume_builderAddonFilters();