<?php
/*
Plugin Name: WP Resume Builder Addon Themes
Plugin URI: http://paratheme.com/
Description: Demo Addon for "WP Resume Builder" used for Themes
Version: 1.0.0
Author: paratheme
Author URI: http://paratheme.com
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Copyright: 	2015 ParaTheme

*/

if ( ! defined('ABSPATH')) exit;  // if direct access 


class WPResumeBuilderAddonThemes{
	
	public function __construct(){
	
		define('wp_rb_addon_plugin_url', WP_PLUGIN_URL . '/' . plugin_basename( dirname(__FILE__) ) . '/' );
		define('wp_rb_addon_plugin_dir', plugin_dir_path( __FILE__ ) );


		//add_action( 'wp_enqueue_scripts', array( $this, 'wp_rb_addon_front_scripts' ) );
		//add_action( 'admin_enqueue_scripts', array( $this, 'wp_rb_addon_admin_scripts' ) );
		
		add_filter('wp_rb_themes', array( $this, 'wp_rb_addon_themes_add' ));
		add_filter('wp_rb_themes_dir', array( $this, 'wp_rb_addon_themes_extra_dir' ));
		add_filter('wp_rb_themes_url', array( $this, 'wp_rb_addon_themes_extra_url' ));
		
		}
		

		
		
	public function wp_rb_addon_themes_add($themes){
		
			$extra_theme = array('flat-blue'=>'Flat Blue',);
						
			return array_merge($themes,$extra_theme);
		}
		
	public function wp_rb_addon_themes_extra_dir($themes_dir){
			
			$main_dir = wp_rb_addon_plugin_dir.'themes/';
			$extra_themes_dir = array('flat-blue'=>$main_dir.'flat-blue',);
			
			return array_merge($themes_dir,$extra_themes_dir);
		}

	public function wp_rb_addon_themes_extra_url($themes_url){
			$main_url = wp_rb_addon_plugin_url.'themes/';
			$extra_themes_url = array('flat-blue'=>$main_url.'flat-blue',);
			
			return array_merge($themes_url,$extra_themes_url);
		}


	}
	
	new WPResumeBuilderAddonThemes();